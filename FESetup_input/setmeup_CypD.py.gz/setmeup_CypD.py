#!/bin/python

import os,sys

try:
    lig = sys.argv[1]
except IndexError:
    print "Usage is script ligand-name"
    sys.exit(-1)

template = """
[globals]
forcefield = amber, ff14SB, tip3p

[ligand]
basedir = poses
file.name = ligand.pdb
molecules = %s

box.type = rectangular
box.length = 12.0
neutralize = yes

min.nsteps = 1000
min.restr_force = 10.0
min.restraint = notsolvent

md.heat.nsteps = 1000
md.heat.restr_force = 10.0
md.heat.restraint = notsolvent

md.constT.nsteps = 1000
md.constT.restr_force = 10.0
md.constT.restraint = notsolvent

md.press.T = 298.0
md.press.nsteps = 20000
md.press.p = 1.0

[protein]
basedir = protein
file.name = protein.pdb
molecules = CypD 

[complex]
pairs = CypD : %s

box.type = rectangular
box.length = 10.0
align_axes = True
neutralize = yes

min.nsteps = 1000
min.restr_force = 10.0
min.restraint = notsolvent

md.heat.nsteps = 1000
md.heat.restr_force = 10.0
md.heat.restraint = notsolvent

md.constT.nsteps = 1000
md.constT.restr_force = 10.0
md.constT.restraint = notsolvent

md.press.T = 298.0
md.press.nsteps = 5000
md.press.p = 1.0
""" % (lig,lig)

setupfile = "setup-%s.in" % lig

stream = open(setupfile,'w')
stream.write(template)
stream.close()

queue="""#!/bin/bash --login
#SBATCH -n 1
#SBATCH -N 1
#SBATCH -o FESetup_%s.out
#SBATCH -e FESetup_%s.err
#SBATCH -p serial
#SBATCH -t 48:00:00

hostname
module load FESetup/1.3dev
FESetup %s > setup-%s.dat
""" %(lig,lig,setupfile,lig)

queuefile = 'submit-%s.sh' % lig

stream = open(queuefile, 'w')
stream.write(queue)
stream.close()
cmd = "sbatch %s" % (queuefile)
#cmd = "FESetup %s > setup-%s.dat &" % (setupfile,lig)
os.system(cmd)
#print cmd
