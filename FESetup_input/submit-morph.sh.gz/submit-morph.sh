#!/bin/bash --login
#SBATCH -n 1
#SBATCH -N 1
#SBATCH -o FESetup_morph_ester_series_CypA.out
#SBATCH -e FESetup_morph_ester_series_CypA.err
#SBATCH -p serial
#SBATCH -t 48:00:00

hostname
module load FESetup/1.3dev
FESetup morph_ester_series_CypA.in > morph_ester_series_CypA.dat
